
import React from 'react';

interface GuestReminderProps {
  onLogin: () => void;
  onClose: () => void;
}

export const GuestReminder: React.FC<GuestReminderProps> = ({ onLogin, onClose }) => {
  return (
    <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[250] w-[calc(100%-3rem)] max-w-md animate-in slide-in-from-bottom-12 duration-500">
      <div className="bg-white dark:bg-gray-800 rounded-3xl p-4 shadow-2xl border border-gray-100 dark:border-gray-700 flex items-center space-x-4">
        <div className="w-12 h-12 rounded-2xl flex-shrink-0 flex items-center justify-center text-white text-xl bg-gradient-to-br from-green-500 to-green-700">
          <i className="fas fa-user-lock"></i>
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-black text-gray-900 dark:text-white">
            Guest Mode
          </h4>
          <p className="text-xs font-bold text-gray-500 dark:text-gray-400">
            Sign up to save your progress!
          </p>
        </div>
        <button 
          onClick={onLogin}
          className="bg-green-600 text-white font-black text-[10px] uppercase tracking-widest px-4 py-2 rounded-xl whitespace-nowrap shadow-lg shadow-green-100 dark:shadow-none"
        >
          Login/Sign Up
        </button>
        <button onClick={onClose} className="text-gray-300 dark:text-gray-500 hover:text-gray-500 dark:hover:text-gray-300 transition-colors">
          <i className="fas fa-times text-sm"></i>
        </button>
      </div>
    </div>
  );
};
