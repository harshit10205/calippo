
import { GoogleGenAI, Type } from "@google/genai";
import { NutritionData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeFoodImage = async (base64Image: string): Promise<NutritionData> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        {
          parts: [
            {
              inlineData: {
                mimeType: 'image/jpeg',
                data: base64Image,
              },
            },
            {
              text: "Analyze this food image. Identify the primary food item and provide its estimated nutritional value per serving. Be precise with protein, fat, and carbs in grams. Provide a short, engaging fitness-focused description.",
            },
          ],
        },
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            foodName: { type: Type.STRING },
            calories: { type: Type.NUMBER },
            protein: { type: Type.NUMBER },
            carbs: { type: Type.NUMBER },
            fat: { type: Type.NUMBER },
            description: { type: Type.STRING },
            healthScore: { type: Type.NUMBER, description: "Health score from 1-100 based on nutrition" },
          },
          required: ["foodName", "calories", "protein", "carbs", "fat", "description", "healthScore"],
        },
      },
    });

    const result = JSON.parse(response.text || '{}');
    if (!result.foodName) {
      // Handle cases where the model returns valid JSON but it's empty or doesn't match the schema
      throw new Error("AI could not identify a food item in the image.");
    }
    return result as NutritionData;
  } catch (error: any) {
    console.error("Gemini Analysis Error:", error);

    // Provide more specific, user-friendly error messages
    const errorMessage = error.toString().toLowerCase();

    if (errorMessage.includes('safety')) {
      throw new Error("Analysis blocked due to safety guidelines. Please use a clear photo of an appropriate food item.");
    } else if (errorMessage.includes('api_key') || errorMessage.includes('permission_denied')) {
      throw new Error("Could not connect to the analysis service. Please check configuration.");
    } else if (errorMessage.includes('invalid_argument')) {
      throw new Error("The image appears to be invalid or corrupted. Please try a different photo.");
    } else if (errorMessage.includes('deadline_exceeded') || errorMessage.includes('unavailable')) {
       throw new Error("The analysis service is currently unavailable. Please try again in a few moments.");
    }

    throw new Error("AI failed to analyze the image. Please try again with a clearer photo.");
  }
};
